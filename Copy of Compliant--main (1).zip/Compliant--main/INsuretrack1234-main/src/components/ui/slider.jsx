export { Slider } from '../slider.jsx';
